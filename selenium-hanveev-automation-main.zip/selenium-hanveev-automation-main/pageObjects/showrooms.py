# import by
from selenium.webdriver.common.by import By

class ShowroomsPage:

    def __init__(self, driver) -> None:
        self.driver = driver

    create = (By.XPATH, '//span[text()="Create"]')
    # customer_name = (By.ID, "o_field_input_121")
    customer_name = (By.XPATH, "(//input[@type='text' and @class='o_input ui-autocomplete-input' and @autocomplete='off'])[1]")
    dropdown = (By.CSS_SELECTOR,'li.o_m2o_dropdown_option')
    search_field = (By.CSS_SELECTOR,'input.o_searchview_input')
    search_suggestion = (By.XPATH, "//em[contains(text(), 'Name')]")

    def click_create(self):
        create = self.driver.find_element(*ShowroomsPage.create)
        create.click()

    def click_customer_name(self):
        customer_name = self.driver.find_element(*ShowroomsPage.customer_name).click()
        # customer_name.click()
    
    def click_dropdown(self):
        dropdown = self.driver.find_element(*ShowroomsPage.dropdown).click()
        # dropdown.click()

    def enter_search_field(self, text):
        search_field = self.driver.find_element(*ShowroomsPage.search_field)
        search_field.send_keys(text)

    def select_search_result(self, name):
        self.driver.find_element(By.XPATH, f"//td[text()='{name}']").click()

    def get_search_suggestion_element(self):
        return ShowroomsPage.search_suggestion
    
    def click_search_suggestion(self):
        search_suggestion = self.driver.find_element(*ShowroomsPage.search_suggestion)
        search_suggestion.click()

