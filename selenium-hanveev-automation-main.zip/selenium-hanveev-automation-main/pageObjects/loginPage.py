# imort By
from selenium.webdriver.common.by import By
# import HomePage
from pageObjects.homePage import HomePage

class LoginPage:

    def __init__(self, driver) -> None:
        self.driver = driver

    username_input = (By.NAME, 'login')
    password_input = (By.NAME, 'password')
    login_button = (By.XPATH, '//button[text()="Login"]')

    def enter_username(self, username):
        element = self.driver.find_element(*LoginPage.username_input)
        element.send_keys(username)

    def enter_password(self, password):
        password_input = self.driver.find_element(*LoginPage.password_input)
        password_input.send_keys(password)
    
    def click_login_button(self):
        login_button = self.driver.find_element(*LoginPage.login_button)
        login_button.click()
        return HomePage(self.driver)
