# import by
from selenium.webdriver.common.by import By
# import ShowroomsPage
from pageObjects.showrooms import ShowroomsPage

class HomePage:

    def __init__(self, driver) -> None:
        self.driver = driver
    
    showroom = (By.XPATH, '//div[text()="Showrooms"]')
    # showroom = driver.find_element(By.XPATH, '//div[text()="Showrooms"]')

    def click_showroom(self):
        showroom = self.driver.find_element(*HomePage.showroom)
        showroom.click()
        return ShowroomsPage(self.driver)