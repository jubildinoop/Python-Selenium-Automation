
import pytest
import time
import logging
import traceback

# import by
from selenium.webdriver.common.by import By
# import WebDriverWait
from selenium.webdriver.support.ui import WebDriverWait
# import expected conditions
from selenium.webdriver.support import expected_conditions as EC

from utilities.BaseClass import BaseClass
# import LoginPage
from pageObjects.loginPage import LoginPage
# import HomePage
from pageObjects.homePage import HomePage
# import ShowroomsPage
from pageObjects.showrooms import ShowroomsPage
# import LoginPageData
from testData.loginPageData import LoginPageData

# fixture will be available through inheritace
# @pytest.mark.usefixtures("setup")
class TestShoppingCart(BaseClass):
    
    def test_e2e(self, get_data):
        # add with clause in a try catch block
        try:
                # get logger from parent class
                log = self.get_logger()

                # access class varible driver
                driver = self.driver
                # create instance of LoginPage
                login_page = LoginPage(driver)

                # login_page.enter_username('ts')
                # login_page.enter_username(get_data[0])
                log.info("username: " + get_data['user-name'])
                login_page.enter_username(get_data['user-name'])
                # username_input = driver.find_element(By.NAME, 'login')
                # username_input.send_keys('ts')

                # login_page.enter_password('123')
                # login_page.enter_password(get_data[1])
                login_page.enter_password(get_data['password'])
                # password_input = driver.find_element(By.NAME, 'password')
                # password_input.send_keys('123')

                home_page = login_page.click_login_button()
                # login_button = driver.find_element(By.XPATH, '//button[text()="Login"]')
                # login_button.click()

                # home_page = HomePage(driver)
                showrooms_page = home_page.click_showroom()
                # showroom = driver.find_element(By.XPATH, '//div[text()="Showrooms"]')
                # showroom.click()
                
                # create instance of ShowroomsPage
                # showrooms_page = ShowroomsPage(driver)
                showrooms_page.click_create()
                # create = driver.find_element(By.XPATH, '//span[text()="Create"]')
                # create.click()
                
                showrooms_page.click_customer_name()
                # create xpath for <input type="text" class="o_input ui-autocomplete-input" autocomplete="off" id="o_field_input_121">
                # customer_name = driver.find_element(By.ID, "o_field_input_121").click()

                showrooms_page.click_dropdown()
                # dropdown = driver.find_element(By.CSS_SELECTOR,'li.o_m2o_dropdown_option').click()
                
                # showrooms_page.enter_search_field(get_data[2])
                log.info("search-key: " + get_data['search-key'])
                showrooms_page.enter_search_field(get_data['search-key'])
                # search_field = driver.find_element(By.CSS_SELECTOR,'input.o_searchview_input')
                # search_field.send_keys('Abhi')
                # time.sleep(1)
                # self.wait_for_presence_of_element_located_with_XPATH("//em[contains(text(), 'Name')]")
                
                showrooms_page.click_search_suggestion()
                # xpath for <a href="#">Search <em>Mill Name</em> for: <strong>abhi</strong></a>
                # search_field = driver.find_element(By.XPATH, "//em[contains(text(), 'Name')]")
                # search_field.click()
                
                log.info("customer-name: " + get_data['customer-name'])
                time.sleep(1)
                # self.wait_for_presence_of_element_located_with_XPATH(f"//td[text()='{get_data['customer-name']}']")
                # showrooms_page.select_search_result(get_data[3])
                showrooms_page.select_search_result(get_data['customer-name'])

                assert True 
                # self.driver.refresh()
                # redirect to http://199.34.21.14:3562/web/login
                
                # sleep for 2 seconds
                time.sleep(2)
        except Exception as e:
            logging.error("Error occurred while creating webdriver instance"+str(e))
            logging.error(e)
            # print stacktrace
            traceback.print_exc()
            assert False
        finally:
            logging.info("End of program")

test_file_name = "testData/input_data.xlsx"

# since the test data is only required inside this test class, we can use class scope
# @pytest.fixture(params=[('ts', '123','Abhi','Abhinand ABC'), ('ts', '123','Jubi','Jubil') ])
# @pytest.fixture(params=LoginPageData.test_login_data)
# @pytest.fixture(params=LoginPageData.get_login_test_data(test_file_name))
@pytest.fixture(params=LoginPageData.get_login_test_data_for_testcase(test_file_name, "Testcase2"))
def get_data(request):
    return request.param