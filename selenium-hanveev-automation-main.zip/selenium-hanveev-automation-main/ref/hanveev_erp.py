
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time
from selenium import webdriver
import logging
import traceback

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# create a service object
service = Service()

# add with clause in a try catch block
try:
    # create a webdriver instance using service using with clause
    with webdriver.Chrome(service=service) as driver:
        driver.get("http://199.34.21.14:3562/")
        # maximize the browser window
        driver.maximize_window()
        driver.implicitly_wait(20)
        driver.set_page_load_timeout(20)

        username_input = driver.find_element(By.NAME, 'login')
        username_input.send_keys('ts')

        password_input = driver.find_element(By.NAME, 'password')
        password_input.send_keys('123')

        login_button = driver.find_element(By.XPATH, '//button[text()="Login"]')
        login_button.click()
        time.sleep(3)

        showroom = driver.find_element(By.XPATH, '//div[text()="Showrooms"]')
        showroom.click()
        time.sleep(3)

        create = driver.find_element(By.XPATH, '//span[text()="Create"]')
        create.click()
        time.sleep(3)

        # create xpath for <input type="text" class="o_input ui-autocomplete-input" autocomplete="off" id="o_field_input_121">
        
        customer_name = driver.find_element(By.ID, "o_field_input_121").click()
        # //li[@class='ui-menu-item']/a[text()='Customer Name']
        # customer_names = driver.find_elements(By.XPATH, "//li[@class='ui-menu-item']")
        # customer_size = len(customer_names)
        # print(customer_size)

        # for customer in customer_names:
        #     print(customer.text)
        #     if customer.text == "Manu":
        #         customer.click()
        #         break
        
        dropdown = driver.find_element(By.CSS_SELECTOR,'li.o_m2o_dropdown_option').click()
        search_field = driver.find_element(By.CSS_SELECTOR,'input.o_searchview_input')
        # search for a key word
        search_field.send_keys('Abhi')
        time.sleep(2)
        # xpath for <em xpath="1">Name</em>
        search_field = driver.find_element(By.XPATH, "//em[contains(text(), 'Name')]")
        search_field.click()
        # xpath for <td class="o_data_cell o_field_cell o_list_char" tabindex="-1" title="Abhinand ABC" name="name" xpath="1">Abhinand ABC</td>
        search_field = driver.find_element(By.XPATH, "//td[text()='Abhinand ABC']")
        search_field.click()

        driver.switch_to.frame("mce_0_ifr") # id or name
        driver.find_element(By.CSS_SELECTOR, "button.dropdown-toggle[aria-expanded='true']").click()
        # a.dropdown-item[data-menu="logout"]
        driver.find_element(By.CSS_SELECTOR, "a.dropdown-item[data-menu='logout']").click()
        driver.switch_to.default_content()
        
        # sleep for 5 seconds
        time.sleep(5)

except Exception as e:
    logging.error("Error occurred while creating webdriver instance")
    logging.error(e)
    # print stacktrace
    # traceback.print_exc()
finally:
    logging.info("End of program")