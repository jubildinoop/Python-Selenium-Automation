
import pytest
# import WebDriverWait
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
# import By
from selenium.webdriver.common.by import By
# import Select
from selenium.webdriver.support.select import Select
# IMPORT LOGGING
import logging
# import inspect
import inspect

@pytest.mark.usefixtures("setup")
class BaseClass:
    
    def wait_for_presence_of_element_located_with_XPATH(self, text):
        wait = WebDriverWait(self.driver, 10)
        wait.until(EC.presence_of_element_located((By.XPATH, text)))

    def wait_for_presence_of_element_located_with_CSS(self, text):
        wait = WebDriverWait(self.driver, 10)
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, text)))

    def select_option_by_visible_text(self, locator, text):
        sel = Select(locator)
        sel.select_by_visible_text(text)

    def logout(self):
        self.driver.find_element(By.CSS_SELECTOR, "button.dropdown-toggle[aria-expanded='true']").click()
        # a.dropdown-item[data-menu="logout"]
        self.driver.find_element(By.CSS_SELECTOR, "a.dropdown-item[data-menu='logout']").click()

    # define common logging configurations here
    def get_logger(self):

        # set logger name from the calling class
        logger_name = inspect.stack()[1][3]
        log = logging.getLogger(logger_name)
        # log = logging.getLogger(__name__)

        fileHandler = logging.FileHandler('logfile.log')
        # specify format 
        formatter = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
        # link the formatter with the handler
        fileHandler.setFormatter(formatter)
        # specify the file
        log.addHandler(fileHandler)
        # specify the level
        log.setLevel(logging.INFO)

        return log