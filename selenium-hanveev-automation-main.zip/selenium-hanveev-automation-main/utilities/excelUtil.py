from openpyxl import load_workbook



def get_list_of_test_data(file_name):
    # book = load_workbook("D:/PythonWorkspace/selenium-framework-python/testData/input_data.xlsx")
    book = load_workbook(file_name)
    sheet = book.active

    # Initialize a list to hold dictionaries
    data_list = []

    for i in range(2, sheet.max_row+1): #skip header row
        # if sheet.cell(row=i, column=1).value == "Testcase2":
            dict = {}
            for j in range(2, sheet.max_column+1):
                dict[sheet.cell(row=1, column=j).value] = sheet.cell(row=i, column=j).value
            print(dict)
            data_list.append(dict)  # Append the dictionary to the list

    return data_list


def get_list_of_test_data_with_test_case(file_name, test_case_name):
    # book = load_workbook("D:/PythonWorkspace/selenium-framework-python/testData/input_data.xlsx")
    book = load_workbook(file_name)
    sheet = book.active

    # Initialize a list to hold dictionaries
    data_list = []

    for i in range(2, sheet.max_row+1): #skip header row
        if sheet.cell(row=i, column=1).value == test_case_name:
            dict = {}
            for j in range(2, sheet.max_column+1):
                dict[sheet.cell(row=1, column=j).value] = sheet.cell(row=i, column=j).value
            print(dict)
            data_list.append(dict)  # Append the dictionary to the list

    return data_list