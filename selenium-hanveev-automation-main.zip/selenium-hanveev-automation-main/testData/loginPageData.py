# import excelUtil
from utilities import excelUtil

class LoginPageData:
    
    test_login_data = [{'user-name':'ts', 'password':'123','search-key':'Abhi','customer-name':'Abhinand ABC'},
                       {'user-name':'ts', 'password':'123','search-key':'Ang','customer-name':'Angelina'}]
    
    # declare a method as static method; no need of selfparameter if it is static method
    @staticmethod
    def get_login_test_data(test_file_name):
        return excelUtil.get_list_of_test_data(test_file_name)
    
    @staticmethod
    def get_login_test_data_for_testcase(test_file_name, test_case_name):
        return excelUtil.get_list_of_test_data_with_test_case(test_file_name, test_case_name)