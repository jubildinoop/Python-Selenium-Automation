# import webdriver

# import driver
from selenium import webdriver
# import by
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import logging
# import traceback
# import traceback
import time
# import time

# create a service object
service = Service()

# add with clause in a try catch block
try:
    # create a webdriver instance using service using with clause
    with webdriver.Chrome(service=service) as driver:
        driver.get("http://199.34.21.14:3562")
        # maximize the browser window
        driver.maximize_window()
        # max timeout for all elements, may nto work find_elements()
        driver.implicitly_wait(10)
        driver.set_page_load_timeout(10)
        # wait for 2 seconds

        # enter user name & password
        # username = driver.find_element(By.ID, "login")
        # username_input.send_keys('admin')
        # # enter password
        # password_input = driver.find_element(By.NAME, 'password')
        # password_input.send_keys('admin')    

        username = driver.find_element(By.ID, "login")
        username.send_keys("ts")

        password = driver.find_element(By.ID, "password")
        password.send_keys("123")


        # time.sleep(2)

        # click on login button
        login_button = driver.find_element(By.XPATH, '//button[text()="Login"]')
        login_button.click()

        showroom_btn = driver.find_element(By.XPATH, '//div[text()="Showrooms"]')
        showroom_btn.click()

        create_btn = driver.find_element(By.CLASS_NAME, "o_list_button_add")
        create_btn.click()

        customer_drp_down = driver.find_element(By.ID,"o_field_input_121")
        customer_drp_down.click()

        # drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="Shivakami"]')
        # drpdwn_btn.click()
        
        # customer_name = driver.find_element(By.ID, "o_field_input_121").click()

        # //li[@class='ui-menu-item']/a[text()='Customer Name']

        customer_names = driver.find_elements(By.XPATH, "//li[@class='ui-menu-item']")
        for customer in customer_names:
            print(customer.text,"---ccccc")
            if customer.text == "Abhi":
                customer.click()
                break
        else:
            dropdown = driver.find_element(By.CSS_SELECTOR,'li.o_m2o_dropdown_option').click()
            search_field = driver.find_element(By.CSS_SELECTOR,'input.o_searchview_input')
            # search for a key word
            search_field.send_keys('Abhi')
            time.sleep(2)
            # xpath for <em xpath="1">Name</em>
            search_field = driver.find_element(By.XPATH, "//em[text()='Mill Name']")
            search_field.click()
            # xpath for <td class="o_data_cell o_field_cell o_list_char" tabindex="-1" title="Abhinand ABC" name="name" xpath="1">Abhinand ABC</td>

            search_field.click()
        

        # drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="Cash"]')
        # drpdwn_btn.click()

        # showroom_drp_down = driver.find_element(By.ID,"o_field_input_52")
        # showroom_drp_down.click()


#   # Find the customer name dropdown
#         customer_name = driver.find_element(By.NAME, "partner_id")
#         customer_name.click()

        # Find the Showroom name dropdown
        showroom_drp_down = driver.find_element(By.ID,"o_field_input_123")
        # showroom_drp_down = driver.find_element(By.NAME, "warehouse_id")
        # showroom_drp_down = driver.find_element(By.CSS_SELECTOR,'input.o_field_input_202')
        showroom_drp_down.click()

      
        drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="Showroom 4"]')
        drpdwn_btn.click()

        # showroom_names = driver.find_elements(By.XPATH, "//li[@class='ui-menu-item']")   
        # print(showroom_names,"kkkkkkkkkk")     
        # for showroom in showroom_names:
        #     print(showroom.text,"---ssss")
        #     if showroom.text == "Showroom 5":
        #         customer.click()
        #         break
        # else:
        #     print("llllllllll")
        #     # dropdown = driver.find_element(By.id,'li.o_m2o_dropdown_option').click()
        #     dropdown = driver.find_element(By.XPATH, "//a[@id='ui-id-126']").click()
        #     search_field = driver.find_element(By.CSS_SELECTOR,'input.o_searchview_input')
        #     # search for a key word
        #     search_field.send_keys('Showroom 17')
        #     time.sleep(2)
        #     # xpath for <em xpath="1">Name</em>
        #     search_field = driver.find_element(By.XPATH, "//em[text()='Place']")
        #     search_field.click()
        #     # xpath for <td class="o_data_cell o_field_cell o_list_char" tabindex="-1" title="Abhinand ABC" name="name" xpath="1">Abhinand ABC</td>
        #     search_field = driver.find_element(By.XPATH, "//td[text()='Showroom 17']")
        #     search_field.click()
        


            
        # Find the session dropdown
        session_name = driver.find_element(By.NAME, "session_id")
        session_name.click()

        drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="POS/00003"]')
        drpdwn_btn.click()

        # showroom_drp_down.click()

        # # Find the lot dropdown
        # lot = driver.find_element(By.NAME, "lot_id")
        # lot.click()

        # drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="06242321307 [Kallimundu] [400.0]"]')
        # drpdwn_btn.click()




        # Finding product

        lot = driver.find_element(By.NAME, "lot_id")
        lot.click()

        input_xpath = "//input[contains(@class, 'o_input') and contains(@class, 'ui-autocomplete-input') and contains(@class, 'ui-autocomplete-loading')]"
        # Use WebDriverWait to wait for the input element to be present
        wait = WebDriverWait(driver, 10)
        input_element = wait.until(EC.presence_of_element_located((By.XPATH, input_xpath)))
        
        # Perform actions on the located input element
        input_element.send_keys("Cotton")

 

        # Locate and click the specific dropdown item
        dropdown_item_xpath = "//a[contains(text(), '0249400950-3 [Cotton Drill] [1350.0]')]"
        dropdown_item = driver.find_element(By.XPATH, dropdown_item_xpath)
        print(dropdown_item.text,"www")
        barcode = dropdown_item.text.split(" ")
        print(barcode,"barcode")
        print(barcode[0],"baEmployeesrcode11")
        dropdown_item.click()  


        # search for a key word
        search_field = driver.find_element(By.NAME,"quantity")
        search_field.clear()
        search_field.send_keys('1.00')


        print(barcode[0],"barcode11")

        # Checking positive scenario with quatity 1
        cart_btn = driver.find_element(By.XPATH, '//span[text()="Add to Cart"]').click()
        cgst_element = driver.find_element(By.NAME ,"cgst")
        sgst_element = driver.find_element(By.NAME ,"sgst")
        igst_element = driver.find_element(By.NAME ,"igst")
        subtotal_element = driver.find_element(By.XPATH ,"//span[@name='price_subtotal']")
        subtotal_value_text = subtotal_element.text
        total = driver.find_element(By.XPATH ,"//span[@name='price_subtotal_incl']")
        total_text = total.text
       
        # Extract values and convert to float
        cgst_value = float(cgst_element.text) if cgst_element.text else 0.0
        sgst_value = float(sgst_element.text) if sgst_element.text else 0.0
        igst_value = float(igst_element.text) if igst_element.text else 0.0
        subtotal_value = float(subtotal_value_text.split('₹')[1]) if subtotal_value_text else 0.0
        total_value = float(total_text.replace('₹', '').replace(',', '').strip()) if total_text else 0.0
        print("Subtotal Value:", subtotal_value)
        print("Total Value:", total_value)

        total_sum = cgst_value + sgst_value + igst_value + subtotal_value
        print("Sum of cgst_value + sgst_value + igst_value + subtotal_value", total_sum)

        if total_value == total_sum:
            print("Value matching..................")



        time.sleep(8)
except Exception as e:
    logging.error("Error occured")
    logging.error(e)
    print(e)