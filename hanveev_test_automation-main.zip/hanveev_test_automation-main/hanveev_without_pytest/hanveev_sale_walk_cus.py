# Import webdriver
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By 
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select 
# 'ActionChains' class to perform various actions, including scrolling, using the mouse
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import logging
from selenium.webdriver.common.alert import Alert
# creating a service object
service = Service()

try:
    with webdriver.Chrome(service=service) as driver:
        driver.get("http://199.34.21.14:3562")
        # To maximize the window
        driver.maximize_window()
        # max timeout for all elements, may nto work find_elements()
        driver.implicitly_wait(10)
        driver.set_page_load_timeout(10)

        # Enter username, password and Log in button
        username_input = driver.find_element(By.NAME, 'login')
        username_input.send_keys('ts')

        password_input = driver.find_element(By.NAME, 'password')
        password_input.send_keys('123')

        login_button = driver.find_element(By.XPATH, '//button[text()="Login"]')
        login_button.click()

        showroom = driver.find_element(By.XPATH, '//div[text()="Showrooms"]')
        showroom.click()

        create = driver.find_element(By.XPATH, '//span[text()="Create"]')
        create.click()

        # Entering name to customer name field
        customer_name = driver.find_element(By.XPATH, "//input[@name='customer_name']")
        customer_name.clear()
        customer_name.send_keys("Fidha")

         # Finding showroom from warehouse_id
        showroom_name = driver.find_element(By.NAME, "warehouse_id").click()
        search_field1 = driver.find_element(By.XPATH, "//a[text()='Showroom 2']").click()

        # Finding session
        session_name = driver.find_element(By.NAME, 'session_id').click()
        search_field2 = driver.find_element(By.XPATH, "//a[text()='POS/00003']").click()

        # Finding product
        lot = driver.find_element(By.NAME, "lot_id")
        lot.click()
        input_xpath = "//input[contains(@class, 'o_input') and contains(@class, 'ui-autocomplete-input') and contains(@class, 'ui-autocomplete-loading')]"
        # Use WebDriverWait to wait for the input element to be present
        wait = WebDriverWait(driver, 10)
        input_element = wait.until(EC.presence_of_element_located((By.XPATH, input_xpath)))
        # Perform actions on the located input element
        input_element.send_keys("cotton saree")
        # Locate and click the specific dropdown item
        dropdown_item_xpath = "//a[contains(text(), \"05178491131 [cotton saree] [456.0]\")]"
        dropdown_item = driver.find_element(By.XPATH, dropdown_item_xpath)
        prod_barcode = dropdown_item.text.split('[')
        print(prod_barcode[0])
        dropdown_item.click()  

        # search for a key word
        search_field = driver.find_element(By.NAME,"quantity")
        search_field.clear()
        search_field.send_keys('1.00')

        # Checking positive scenario with quatity 1
        cart_btn = driver.find_element(By.XPATH, '//span[text()="Add to Cart"]').click()
        cgst_element = driver.find_element(By.NAME ,"cgst")
        sgst_element = driver.find_element(By.NAME ,"sgst")
        igst_element = driver.find_element(By.NAME ,"igst")
        subtotal_element = driver.find_element(By.XPATH ,"//span[@name='price_subtotal']")
        subtotal_value_text = subtotal_element.text
        total = driver.find_element(By.XPATH ,"//span[@name='price_subtotal_incl']")
        total_text = total.text
       
        # Extract values and convert to float
        cgst_value = float(cgst_element.text) if cgst_element.text else 0.0
        sgst_value = float(sgst_element.text) if sgst_element.text else 0.0
        igst_value = float(igst_element.text) if igst_element.text else 0.0
        subtotal_value = float(subtotal_value_text.split('₹')[1]) if subtotal_value_text else 0.0
        total_value = float(total_text.replace('₹', '').replace(',', '').strip()) if total_text else 0.0
        print("Subtotal Value:", subtotal_value)
        print("Total Value:", total_value)

        total_sum = cgst_value + sgst_value + igst_value + subtotal_value
        print("Sum of CGST + SGST + IGST + Subtotal :", total_sum)

        if total_value == total_sum:
            print("Value Matching... !")

            # Execute JavaScript to show an alert
            alert_message = "Value Matching.................."
            driver.execute_script(f"alert('{alert_message}');")
            time.sleep(6)

           
        else:
            # Execute JavaScript to show an alert
            alert_message = "Value Not Matching.................."
            driver.execute_script(f"alert('{alert_message}');")
            time.sleep(6)

        # sleep for 5 seconds
        time.sleep(5)

except Exception as e:
    logging.error("Error occured")
    logging.error(e)