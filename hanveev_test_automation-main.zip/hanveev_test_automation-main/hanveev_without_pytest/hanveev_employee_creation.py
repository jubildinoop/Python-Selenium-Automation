# Import webdriver
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
# 'ActionChains' class to perform various actions, including scrolling, using the mouse
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import logging

import time
# import time

# create a service object
service = Service()

# add with clause in a try catch block
try:
    # create a webdriver instance using service using with clause
    with webdriver.Chrome(service=service) as driver:
        driver.get("http://199.34.21.14:3562")
        # maximize the browser window
        driver.maximize_window()
        # max timeout for all elements, may nto work find_elements()
        driver.implicitly_wait(10)
        driver.set_page_load_timeout(10)

        # enter user name & password
        username = driver.find_element(By.ID, "login")
        username.send_keys("ts")

        password = driver.find_element(By.ID, "password")
        password.send_keys("123")


        # time.sleep(2)

        # click on login button
        login_button = driver.find_element(By.XPATH, '//button[text()="Login"]')
        login_button.click()

        showroom_btn = driver.find_element(By.XPATH, '//div[text()="Organization"]')
        showroom_btn.click()

        emp = driver.find_element(By.XPATH,'//span[text()="Employees"]').click()
        emp_submenu = driver.find_element(By.XPATH, '//a[text()="Add Employee"]').click()

        emp_name = driver.find_element(By.XPATH, "//input[@name='name']")
        emp_name.clear()
        emp_name.send_keys("Abhinand K R")

        emp_code = driver.find_element(By.XPATH, "//input[@name='employee_code']")
        emp_code.clear()
        emp_code.send_keys("Abhinand-05")

        emp_type = Select(driver.find_element(By.XPATH, "//select[@name='hanveev_employee_type']"))
        # emp_type.select_by_value('"staff"')
        emp_type.select_by_visible_text('Staff')

        emp_dob = driver.find_element(By.XPATH, "//input[@name='birthday']")
        emp_dob.click()

        dob = "1999-07-11"
        emp_dob.clear()
        emp_dob.send_keys(dob)
        emp_dob.send_keys(Keys.RETURN)

        emp_mob = driver.find_element(By.XPATH, "//input[@name='mobile_phone']")
        emp_mob.clear()
        emp_mob.send_keys('8547851707')

        emp_email=driver.find_element(By.ID,"o_field_input_100")
        emp_email.clear()
        emp_email.send_keys('abhinandkr05@gmail.com')

        

        emp_gender = Select(driver.find_element(By.NAME, 'gender'))
        emp_gender.select_by_visible_text('Male')
    
                
        emp_cast=driver.find_element(By.XPATH,'//input[@name="caste"]')
        emp_cast.send_keys('viswakarma')

        add_street1=driver.find_element(By.XPATH,'//input[@name="street"]')
        add_street1.send_keys('iritty')

        add_street2=driver.find_element(By.XPATH,'//input[@name="street2"]')
        add_street2.send_keys('padiyoor')
        
    
        add_city = driver.find_element(By.NAME, "district_addr_id").click()
        drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="Kannur"]')
        drpdwn_btn.click()
        

        add_pin =driver.find_element(By.XPATH,'//input[@name="zip"]')
        add_pin.send_keys('670703')


        add_RO=driver.find_element(By.ID,'o_field_input_107')
        add_RO.send_keys('RO-Kannur')
        add_RO.click()
        time.sleep(5)

        add_job_title=driver.find_element(By.ID,'o_field_input_110')
        add_job_title.send_keys('ADM')

        emp_joining_date = driver.find_element(By.XPATH, "//input[@name='joining_date']")
        emp_joining_date.click()

        joining_date = "2022-07-01"
        emp_joining_date.send_keys(joining_date)
        emp_joining_date.send_keys(Keys.RETURN)
        emp_joining_date.click()


        add_mode_of_appoinment = driver.find_element(By.ID, "o_field_input_112").click()
        drpdwn_btn = driver.find_element(By.XPATH, "//option[contains(text(),'PSC')]")
        drpdwn_btn.click()

        add_mode_of_qualification = driver.find_element(By.ID, "o_field_input_113").click()
        drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="BCA"]')
        drpdwn_btn.click()

        add_payscale = driver.find_element(By.ID, "o_field_input_114").click()
        drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="Payscale Revision 2004 Master Scale"]')
        drpdwn_btn.click()
        
       
        add_payscale_year = driver.find_element(By.ID, "o_field_input_115").click()
        drpdwn_btn = driver.find_element(By.XPATH, '//a[text()="4510.0 - 1 Year"]')
        drpdwn_btn.click()

        add_emp_type = Select(driver.find_element(By.ID, "o_field_input_116"))
        add_emp_type.select_by_visible_text('Temporary')
  
        add_emp=driver.find_element(By.XPATH,'//span[text()="Add Employee"]').click()



        # sleep for 5 seconds
        time.sleep(5)
except Exception as e:
    logging.error("Error occured")
    logging.error(e)
    print(e)