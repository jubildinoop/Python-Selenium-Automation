import pytest
import inspect
import logging

@pytest.mark.usefixtures("setup")
class BaseClass:
    def get_logger(self):
        # set logger name from the calling class
        logger_name = inspect.stack()[1][3]
        log = logging.getLogger(logger_name)
        # log = logging.getLogger(__name__)
        fileHandler = logging.FileHandler('logfile.log')
        # specify format
        formatter = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
        # link the formatter with the handler
        fileHandler.setFormatter(formatter)
        # specify the file
        log.addHandler(fileHandler)
        # specify the level
        log.setLevel(logging.INFO)
        return log

