import pytest
# Import webdriver
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By 
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select 
# 'ActionChains' class to perform various actions, including scrolling, using the mouse
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import logging
from baseClass import BaseClass
import os
import datetime


class TestShoppingCart(BaseClass):
    def test_cart(self):
        try:
            # log = logging.getLogger(__name__)

        
            # # Get today's date
            # today_date = datetime.date.today()
            # # Format the date as "YYYY-MM-DD"
            # formatted_date = today_date.strftime("%Y-%m-%d")
            # # Create the log file name
            # log_file_name = f"log_{formatted_date}.txt"

            # fileHandler = logging.FileHandler(log_file_name)
            # # specify format
            # formatter = logging.Formatter("%(asctime)s : %(levelname)s : %(name)s : %(message)s")
            # # link the formatter with the handler
            # fileHandler.setFormatter(formatter)
            # # specify the file
            # log.addHandler(fileHandler)
            # # specify the level
            # log.setLevel(logging.ERROR)

            driver = self.driver
            username_input = driver.find_element(By.NAME, 'login')
            username_input.send_keys('ts')

            password_input = driver.find_element(By.NAME, 'password')
            password_input.send_keys('123')

            login_button = driver.find_element(By.XPATH, '//button[text()="Login"]')
            login_button.click()
            # log.info("emp creation")

            showroom = driver.find_element(By.XPATH, '//div[text()="Showrooms"]')
            showroom.click()

            create = driver.find_element(By.XPATH, '//span[text()="Create"]')
            create.click()

            # Entering name to customer name field
            customer_name = driver.find_element(By.XPATH, "//input[@name='customer_name']")
            customer_name.clear()
            customer_name.send_keys("Ammu")
            
            # Finding showroom from warehouse_id
            showroom_name = driver.find_element(By.NAME, "warehouse_id").click()
            search_field1 = driver.find_element(By.XPATH, "//a[text()='Showroom 2']").click()

            # Finding session
            session_name = driver.find_element(By.NAME, 'session_id').click()
            search_field2 = driver.find_element(By.XPATH, "//a[text()='POS/00003']").click()

            # Finding product 
            lot = driver.find_element(By.NAME, "lot_id")
            lot.click()
            input_xpath = "//input[contains(@class, 'o_input') and contains(@class, 'ui-autocomplete-input') and contains(@class, 'ui-autocomplete-loading')]"
            # Use WebDriverWait to wait for the input element to be present
            wait = WebDriverWait(driver, 10)
            input_element = wait.until(EC.presence_of_element_located((By.XPATH, input_xpath)))
            # Perform actions on the located input element
            input_element.send_keys("cotton saree")
            # Locate and click the specific dropdown item
            # dropdown_item_xpath = "//a[contains(text(), \"04166191059-1 [Kerchief / face towel] [1200.0]\")]"
            dropdown_item_xpath = "//a[contains(text(), '05178491131 [cotton saree] [456.0]')]"
            dropdown_item = driver.find_element(By.XPATH, dropdown_item_xpath)
            prod_barcode = dropdown_item.text.split('[')
            print(prod_barcode[0])
            dropdown_item.click()  

            # search for a key word
            search_field = driver.find_element(By.NAME,"quantity")
            search_field.clear()
            search_field.send_keys('1.00')

            # Checking positive scenario with quatity 1
            cart_btn = driver.find_element(By.XPATH, '//span[text()="Add to Cart"]').click()
            cgst_element = driver.find_element(By.NAME ,"cgst")
            sgst_element = driver.find_element(By.NAME ,"sgst")
            igst_element = driver.find_element(By.NAME ,"igst")
            subtotal_element = driver.find_element(By.XPATH ,"//span[@name='price_subtotal']")
            subtotal_value_text = subtotal_element.text
            total = driver.find_element(By.XPATH ,"//span[@name='price_subtotal_incl']")
            total_text = total.text
            
            # Extract values and convert to float
            cgst_value = float(cgst_element.text) if cgst_element.text else 0.0
            sgst_value = float(sgst_element.text) if sgst_element.text else 0.0
            igst_value = float(igst_element.text) if igst_element.text else 0.0
            subtotal_value = float(subtotal_value_text.split('₹')[1]) if subtotal_value_text else 0.0
            total_value = float(total_text.replace('₹', '').replace(',', '').strip()) if total_text else 0.0
            print("Subtotal Value:", subtotal_value)
            print("Total Value:", total_value)

            total_sum = cgst_value + sgst_value + igst_value + subtotal_value
            print("Sum of CGST + SGST + IGST + Subtotal", total_sum)

            if total_value == total_sum:
                print("Value matching..................")
                # Execute JavaScript to open the popup
                js_script = "alert('Sum of CGST,SGST,IGST and Subtotal is equal to Total');"
                driver.execute_script(js_script)
                time.sleep(5)

                # Switch to the alert (popup) and accept it
                alert = driver.switch_to.alert
                alert.accept()

            assert True
        except Exception as e:
            logging.error("Error occured")
            logging.error(e)

            assert False, "Login failed" + str(e)


