import pytest

@pytest.mark.usefixtures("setup")
class TestFixtureDemo:
    def test_demo1(self):
        print("Statement 1, i will execute first")

    def test_demo2(self):
        print("Statement 2, i will execute second")

    def test_demo3(self):
        print("Statement 3, i will execute third")

    def test_demo4(self):
        print("Statement 4, i will execute fourth")
    