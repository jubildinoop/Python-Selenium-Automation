import pytest


@pytest.mark.smoke
def test_hello_world():
    print("Hello World!")
    assert True

@pytest.mark.xfail
def test_find_big():
    a = 1
    b = 2
    assert a > b , "Test failed"

# skipping the code
@pytest.mark.skip
def test_add():
    result = 1+8
    assert result == 10, "Test sum failed"