def test_addition():
    result = 2 + 3
    assert result == 5, "Addition test failed"

def test_multiplication():
    result = 5 * 10
    assert result == 50, "Multiplication failed"